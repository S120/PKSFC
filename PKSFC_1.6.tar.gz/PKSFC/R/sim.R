#' sfc models.
#' 
#' an sfc object that models the sim models
#' 
#' @name sim
#' @docType data
NULL