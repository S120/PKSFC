#' master parm list
#' 
#' contains all parameters to make thing neater
#' 
#' @author David O'Sullivan
#' 